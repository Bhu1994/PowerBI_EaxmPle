# Screenshots of Power BI *Maven Market* Final Report :-

## Report View : 

### 1) Topline Performance -![Report View - Topline Performance](https://user-images.githubusercontent.com/98680598/177703538-21c3efd9-6afb-450b-bfd7-f47de1f5db87.jpg)

### 2) Notes -![Report View - Notes](https://user-images.githubusercontent.com/98680598/177703552-7a1e81d3-8e05-495c-b6d6-f2c64c58b877.jpg)

## Data View :![Data View](https://user-images.githubusercontent.com/98680598/177703562-21c7c5b3-9d90-4ee1-840e-41e479b72059.jpg)

## Model View :![Model View](https://user-images.githubusercontent.com/98680598/177703566-cfdecde8-90d9-4600-89d4-816f6fbbc1fc.jpg)
