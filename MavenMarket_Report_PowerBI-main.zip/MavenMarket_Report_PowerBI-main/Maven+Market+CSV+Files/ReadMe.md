# CSV files for following tables in Power BI :- 
## 2 data tables
## 5 lookup tables
